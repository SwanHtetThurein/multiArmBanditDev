"""Bandit framework package."""
